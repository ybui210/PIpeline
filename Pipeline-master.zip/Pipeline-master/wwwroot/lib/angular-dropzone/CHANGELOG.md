## 0.1.2 (2015-04-28)

Bugfixes:
  - bower.json should point to Dropzone.js as dependency
  - update main in bower.json to correct path
