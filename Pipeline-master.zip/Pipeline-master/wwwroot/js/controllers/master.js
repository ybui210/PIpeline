﻿(function () {
    angular.module('pipeline').controller('MasterController', [function () {

    }]);
})();
