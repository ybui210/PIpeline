﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Pipeline.ViewModels
{
    public class EditListing : CreateListing
    {
        public Guid ID { get; set; }
       
    }
}
